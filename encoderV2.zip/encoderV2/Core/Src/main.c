/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "usart.h"
#include "tim.h"
#include "usb_otg.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include<math.h>
#include "stdbool.h"
#include "stdio.h"
#include<string.h>
#include "stdlib.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

int direction = 1; //1 = CW , -1 = CCW
float newtime;
float prevtime;
float RPM;




float FreqEncoder;
bool PWMState;
char message[60];
int pulses;

int OldPrintTime;
int LastTime;
float EMALast;
float EMACurrent;
float alpha = 0.60;
float EMARPMC=0.0;
float EMARPML=0.0;
float alphaRPM = 0.5;
float testtime;
int timecountPULSE;
float period;
float HPeriod;
float stepsize = 0.0333;
bool isFirst;
int valueFirst;
float FreqPulse;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_LPUART1_UART_Init();
  MX_USART3_UART_Init();
  MX_USB_OTG_FS_PCD_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_CAN1_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
  HAL_TIM_IC_Start_IT(&htim3, TIM_CHANNEL_1);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  if ((HAL_GetTick()-LastTime)>25){
	  		  RPM=0.0;
	  		  EMARPMC = 0.0;
	  	  }
	  if (abs(RPM)<20.0){
		  HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
		  HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_3);
		  PWMState = false;
	  }
	  else {
		  FreqEncoder = abs((RPM/60)*1000*2);
		  period =floor(HAL_RCC_GetPCLK2Freq() / FreqEncoder)-1;
		  TIM1->ARR = period;
		  if (direction == 1){
			  TIM1->CCR1 = 0;
			  TIM1->CCR2 = period;
			  TIM1-> CCR3 = (period/2);
			  TIM1->CCR4 = (period/2);

		  }
		  else{
			  TIM1->CCR3 = 0;
			  TIM1->CCR4 = period;
			  TIM1-> CCR1 = (period/2);
			  TIM1->CCR2 = (period/2);
		  }
		  if (PWMState == false){
			  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
			  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
			  PWMState = true;
		  }
	  }
	  //HAL_Delay(5000);

	  //HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
	  //HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_3);
	  //TIM1->ARR = period;
	  //HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	  //HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
	  //period =period + 300;
	  if ((HAL_GetTick()-OldPrintTime)>1000){
		  sprintf(message, "RPM: %f \nDirection: %d\nFrequency: %f\n",RPM,direction,FreqPulse);
		  //printf("\n%s",message);
		  HAL_UART_Transmit(&hlpuart1,(uint8_t*)message, strlen(message)	, 0xFFFF);
		  OldPrintTime = HAL_GetTick();
	  }

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage 
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_BYPASS;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 30;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART3|RCC_PERIPHCLK_LPUART1
                              |RCC_PERIPHCLK_USB;
  PeriphClkInit.Usart3ClockSelection = RCC_USART3CLKSOURCE_PCLK1;
  PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_PCLK1;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLLSAI1;
  PeriphClkInit.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_MSI;
  PeriphClkInit.PLLSAI1.PLLSAI1M = 1;
  PeriphClkInit.PLLSAI1.PLLSAI1N = 24;
  PeriphClkInit.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_48M2CLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  /** Enable MSI Auto calibration 
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/* USER CODE BEGIN 4 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	/*switch (GPIO_Pin){
	case Hall_Pin:
		newtime = HAL_GetTick();
		pulses = pulses + 1;
		//pulsetime = newtime - prevtime;
		if (pulsecount <= 4 ){
			pulsecount++;
			direction = 1;
		}else{
			direction = -1;
		}
		if (direction == 1){
			PulseCW++;
		}else{
			PulseCCW++;
		}

		if ((newtime - prevtime)>=1000){
			//avgpulses =(pulses + pulsesprev + pulsesprev2)/3;
			//pulsesprev2=pulsesprev;
			//pulsesprev=pulses;
			//pulses = 0;
			//EMALast = EMACurrent;
			//EMACurrent = ((pulses * alpha) + EMALast *(1-alpha));
			//PPM=EMACurrent;

			RPM = (pulses/30)*60*direction;

			EMARPML = EMARPMC;
			EMARPMC = ((RPM*alphaRPM)+EMARPML*(1-alphaRPM));
			pulses = 0;
			prevtime = newtime;

		}

		//PPM = (1000/pulsetime)*60;

		//prevtime = newtime;
		period = (timecountPULSE * 100)/(1000);
		RPM = (stepsize/(period/2))*1000*60;
		timecountPULSE = 0;
		EMARPML = EMARPMC;
		EMARPMC = ((RPM*alphaRPM)+EMARPML*(1-alphaRPM));

		break;
	case Direc_Pin:

		break;
	}*/
}
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim){
	if ((htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)&&(htim->Instance==TIM3)){
			valueFirst = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
			FreqPulse= HAL_RCC_GetPCLK1Freq()/valueFirst;
			period = (1/FreqPulse)*1000; //unit: ms
			HPeriod = period/2;
			RPM = (stepsize/HPeriod)*1000*60;
			LastTime = HAL_GetTick();
			__HAL_TIM_SET_COUNTER(htim,0);
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
